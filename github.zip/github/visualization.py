import turtle
import tkinter as tk
import main
import math
import copy

s = False
f = True
c = 20

raktar = []
official_coordinates = []
coordinates = []
objects = []

TURTLE_SIZE = 20


def calcDist(x1, y1, x2, y2):
    """

    A Pitagorasz-tétel segítségével kiszámolja a távolságot 2 pont között.

    """
    return math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)

def create_stops():
    for i in range(len(coordinates)):
        yertle = turtle.RawTurtle(screen,visible=False)
        yertle.shape("data/warehouse2.gif")
        yertle.penup()
        yertle.goto(coordinates[i][0]*7-80, coordinates[i][1]*2-50)
        yertle.pendown()
        yertle.showturtle()

        objects.append(yertle)



def setup():
    global s
    plane.color("Yellow")
    plane.penup()
    plane.speed(5)
    plane.goto(raktar[0] * 7 - 80, raktar[1] * 2 - 50)
    plane.showturtle()

    start.shape("data/start.gif")

    start.penup()
    start.goto(raktar[0] * 7 - 80, raktar[1] * 2 - 50)
    start.pendown()
    start.showturtle()

    create_stops()
    s = True
def got(x, y):
        rotate(plane.xcor(), plane.ycor(),
               x * 7 - 80, y * 2 - 50)
        plane.goto(x * 7 - 80, y * 2 - 50)

def goh(x,y):

        rotate(x * 7 - 80, y* 2 - 50,
               raktar[0] * 7 - 80, raktar[1] * 2 - 50)
        plane.goto(raktar[0] * 7 - 80, raktar[1] * 2 - 50)

def reset():
    global coordinates
    text.set("0 km")
    coordinates = copy.deepcopy(official_coordinates)
    plane.hideturtle()
    plane.goto(raktar[0] * 7 - 80, raktar[1] * 2 - 50)
    plane.showturtle()
    for i in objects:
        i.shape("data/warehouse2.gif")


def press():
    run()

def run():
    reset()
    global s
    if s == False:
        return
    else:
        pass
    flag = True
    counter = 20


    repulo = main.Repulo(125, 1, raktar, coordinates)

    while repulo.pointer < counter:  # A ciklus 19-szer fut le, mivel a raktáron és a hiányos kordinátán kívül  18 kordináta van, ahova el kell menni

        if flag and repulo.current_size != repulo.MAX_SIZE and repulo.current_size < repulo.kordinatak[repulo.pointer][
            2]:
            pass
        else:
            if (len(
                    repulo.utvonal) > 0):  # Ha előző lépésben a raktárban volt, akkor kiszámolja az onnantól számított távolságot, másképp az előző ponttól számított távolságot

                if (repulo.utvonal[-1] == -1):

                    repulo.distance += calcDist(x1=repulo.raktar[0], y1=repulo.raktar[1],
                                                x2=repulo.kordinatak[repulo.pointer][0],
                                                y2=repulo.kordinatak[repulo.pointer][1])
                else:

                    repulo.distance += calcDist(x1=repulo.kordinatak[repulo.pointer][0],
                                                y1=repulo.kordinatak[repulo.pointer][1],
                                                x2=repulo.kordinatak[repulo.utvonal[-1]][0],
                                                y2=repulo.kordinatak[repulo.utvonal[-1]][1])

        print(repulo.kordinatak[repulo.pointer])
        repulo.utvonal.append(repulo.pointer)  # Utvonal mentés
        got(repulo.kordinatak[repulo.pointer][0], repulo.kordinatak[repulo.pointer][1])
        if repulo.current_size > repulo.kordinatak[repulo.pointer][
            2]:  # Ha a rakomány több, mint a lerakandó ajándék, akkor ürít és megy tovább

            repulo.dropGift()
            objects[repulo.pointer - 1].shape("data/finished.gif")

        elif repulo.current_size == repulo.kordinatak[repulo.pointer][2]:  # Ha egyforma, akkor ürít és megy haza

            repulo.emptyAll()
            repulo.goHome()
            goh(repulo.kordinatak[repulo.pointer][0],repulo.kordinatak[repulo.pointer][1])
            objects[repulo.pointer - 1].shape("data/finished.gif")

        else:

            if flag and repulo.current_size != repulo.MAX_SIZE:  # A kevesebb és az első feladatot csinálja, akkor ürít és haza, másképpen csak hazamegy

                repulo.goHome()
                goh(repulo.kordinatak[repulo.pointer][0],repulo.kordinatak[repulo.pointer][1])
            else:

                repulo.emptyAll()
                repulo.goHome()
                goh(repulo.kordinatak[repulo.pointer][0],repulo.kordinatak[repulo.pointer][1])

        if (repulo.pointer >= counter - 1 and repulo.kordinatak[counter - 1][
            2] == 0):  # Ha a végén járunk, akkor hazatérünk

            repulo.teresCounter += 1
            repulo.distance += calcDist(x1=raktar[0], y1=raktar[1], x2=repulo.kordinatak[18][0],
                                        y2=repulo.kordinatak[18][1])
            repulo.utvonal.append(-1)

            break

        ford.set(f"{repulo.teresCounter} térés")
        text.set(f"{round(repulo.distance)} km")
        root.update()

    ford.set(f"{repulo.teresCounter} térés")
    text.set(f"{round(repulo.distance)} km")
    root.update()

    print("Térések száma: ", repulo.teresCounter)
    print("Megtett út: ", int(repulo.distance * 1000), "km")
    print(repulo.utvonal)
    s = False


def rotate(x1,y1,x2,y2):
    angle = abs(math.degrees(math.atan((y1-y2)/(x1-x2))))

    side = 1
    if x1 > x2 and y1 > y2:
        angle += 180
    elif x1 > x2 and y1 < y2:
        angle += 90
    elif x1 < x2 and y1 > y2:
        angle += 270
    elif x1 < x2 and y1 < y2:
        angle += 0

    print(x1, y1,"->", x2, y2," Heading to", angle)
    plane.setheading(angle)

def mode1():
    f = False
    c = 19

def mode2():
    f = True
    c = 20

if __name__ == "__main__":
    raktar, official_coordinates = main.readData("raktar.txt")
    coordinates = copy.deepcopy(official_coordinates)
    root = tk.Tk()
    root.title("Visualization")
    root.geometry("{}x{}".format(1200,700))


    window = tk.Canvas(master = root,width = 1000,height = 690,bd=5,relief='ridge')
    window.place(x=0,y= 0)

    screen = turtle.TurtleScreen(window)
    screen.bgpic("data/bg.gif")

    screen.addshape("data/warehouse2.gif")
    screen.addshape("data/start.gif")
    screen.addshape("data/finished.gif")
    screen.addshape("data/plane.gif")



    plane = turtle.RawTurtle(canvas=screen, shape="classic", visible=False)
    start = turtle.RawTurtle(canvas=screen)

    startButton = tk.Button(master=root, text="start", command=lambda : run())
    startButton.place(x=1050, y=20,width = 100,height =100)

    Button1 = tk.Button(master=root, text="Mode 1", command=lambda: mode1())
    Button1.place(x=1050, y=250, width=100, height=100)
    Button2 = tk.Button(master=root, text="Mode 2", command=lambda: mode2())
    Button2.place(x=1050, y=150, width=100, height=100)

    text = tk.StringVar()
    text.set("0 km ")

    ford = tk.StringVar()
    ford.set("0 fordulás")

    labelford = tk.Label(master=root,textvariable = ford, font=("Arial",15))
    labelford.place(x = 1050,y= 500)

    label = tk.Label(master=root,textvariable = text,font=("Arial",15))
    label.place(x=1050,y=550)
    setup()

    root.mainloop()
